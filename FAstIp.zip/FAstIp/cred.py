#Twilio Details

account_sid = 'AC16a948c3a950e25dd8e6060f87cf8172'
auth_token = 'bf4c4b21871f154475dd6a2b70d40036'
twilionumber = '+19108124952'
twiliosmsnumber = '+19108124952'

#FC Bot
API_TOKEN = ""

#Host URL
callurl = 'https://a3702bf898c2.ngrok.io'
twiliosmsurl = 'https://a3702bf898c2.ngrok.io/sms'









